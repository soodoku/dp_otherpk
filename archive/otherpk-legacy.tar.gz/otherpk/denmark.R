##################################################
##   											##
##      Other PK Tabs, Last Edited: 12.29.10  	##
##   											##
##################################################

# Load Data
load("data/CDD/Denmark/den.rdata")

paired <- function(t0, t1, t2)
{
	# NA treated as 0 for pk questions.
	# Not missing on x, y, and people who turned in their t2 questionnaires. 
	# tester: x <- den$t1pk1; y <- den$t2pk1
	nona <- !is.na(t0) & !is.na(t1) & !is.na(t2)
	n1 <- sum(nona)
	mu.t0 <- kros(mean(t0[nona]))
	mu.t1 <- kros(mean(t1[nona]))
	mu.t2 <- kros(mean(t2[nona]))
	t1t0 <- t.test(t1,t0, paired=T)
	t2t1 <- t.test(t2,t1, paired=T)
	t2t0 <- t.test(t2,t0, paired=T)
	c(mu.t0, mu.t1, mu.t2, paste(kros(t1t0$est), stars(t1t0$p.value), sep=""), paste(kros(t2t1$est), stars(t2t1$p.value), sep=""), paste(kros(t2t0$est), stars(t2t0$p.value), sep=""), n1)
}

##***************************##
##  Table 1 Knowledge Gain   ##
##***************************##

tab1.know <- data.frame(qno=NA, t0=NA, t1=NA, t2=NA, t1t0diff=NA, t2t1diff=NA, t2t0diff=NA, n=1:23)
## Ref. Knowledge
tab1.know[1,] <- c("Denmark could be fined if the national fiscal deficit is too large (Yes)", with(den, paired(t0pk1, t1pk1, t2pk1)))
tab1.know[2,] <- c("Denmark can decide its own interest rates (no)",with(den, paired(t0pk2, t1pk2, t2pk2)))
tab1.know[3,] <- c("Denmark can decide its taxes (yes)",with(den, paired(t0pk3, t1pk3, t2pk3)))
tab1.know[4,] <- c("Single currency will enter (2004)",with(den, paired(t0pk4, t1pk4, t2pk4)))
tab1.know[5,] <- c("Danish National Bank",with(den, paired(t0pk5, t1pk5, t2pk5)))
tab1.know[6,] <- c("Euro coins have a national side (Yes)",with(den, paired(t0pk6, t1pk6, t2pk6)))
tab1.know[7,] <- c("unstable foreign exchange market (Yes)",with(den, paired(t0pk7, t1pk7, t2pk7)))
## Party Placement
tab1.know[8,]  <- c("Movement against the European Union (against)", with(den, paired(t0ppk1, t1pk1, t2ppk1)))
tab1.know[9,]  <- c("June Movement (against)",with(den, paired(t0ppk2, t1ppk2, t2ppk2)))
tab1.know[10,] <- c("Social Democrats (for)",with(den, paired(t0ppk3, t1ppk3, t2ppk3)))
tab1.know[11,] <- c("Social Liberals (for)",with(den, paired(t0ppk4, t1ppk4, t2ppk4)))
tab1.know[12,] <- c("Conservative Party (for)",with(den, paired(t0ppk5, t1ppk5, t2ppk5)))
tab1.know[13,] <- c("Center Democrats (for)",with(den, paired(t0ppk6, t1ppk6, t2ppk6)))
tab1.know[14,] <- c("Socialist People's Party (against)",with(den, paired(t0ppk7, t1ppk7, t2ppk7)))
tab1.know[15,] <- c("Danish People's Party (against)",with(den, paired(t0ppk8, t1ppk8, t2ppk8)))
tab1.know[16,] <- c("Christian People's Party (against)",with(den, paired(t0ppk9, t1ppk9, t2ppk9)))
tab1.know[17,] <- c("Liberal Party (for)", with(den, paired(t0ppk10, t1ppk10, t2ppk10)))
tab1.know[18,] <- c("Progress Party (against)",with(den, paired(t0ppk11, t1ppk11, t2ppk11)))
tab1.know[19,] <- c("Unity Party (against)",with(den, paired(t0ppk12, t1ppk12, t2ppk12)))
tab1.know[20,] <- c("Freedom 2000 (against)",with(den, paired(t0ppk13, t1ppk13, t2ppk13)))
## Aggregate Measures
tab1.know[21,] <- c("Euro knowledge",with(den, paired(t0refpk, t1refpk, t2refpk)))
tab1.know[22,] <- c("Political knowledge",with(den, paired(t0partpk, t1partpk, t2partpk)))
tab1.know[23,] <- c("Total knowledge",with(den, paired(t0know, t1know, t2know)))
write.csv(tab1.know, file="otherpk/res/tab1.know.csv")

#sum <- summary(with(den, lm(I(t3know - t1know) ~ log(age) + female + t3part*ppeduc)))
#tab5 <- cbind(sum$coef, paste(kros(sum$coef[,1]), stars(sum$coef[,4])))

